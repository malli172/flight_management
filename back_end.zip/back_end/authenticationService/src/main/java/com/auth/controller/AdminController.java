package com.auth.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.auth.repo.SignUpRepository;
import com.auth.request.SignUpRequest;

@RestController
@RequestMapping("/auth/admin")
public class AdminController {
	
	@Autowired
	private SignUpRepository repo;

	@GetMapping("/getAllUsers")
	public List<SignUpRequest> getAllUsers() {
		List<SignUpRequest> list=new ArrayList<>();
		for(SignUpRequest login: this.repo.findAll()) {
			String role = login.getRole();
			if (role.equals("ROLE_USER")) {
			   list.add(login);
			}
		}
		return list;
	}
}
