package com.auth.exceptionHandler;

public class ResourceNotFoundException extends Exception {

	public ResourceNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
