package com.auth.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.auth.client.CheckInClient;

@RestController
@RequestMapping("/auth")
public class CheckInController {
	
	@Autowired
	private CheckInClient checkin;


	@GetMapping("/checkIn/{bookingId}")
	public String preformCheckIn(@PathVariable String bookingId) {
		return checkin.preformCheckIn(bookingId);
	}

	@DeleteMapping("/checkIn/{bookingId}")
	public String deleteCheckIn(@PathVariable String bookingId) {
		return checkin.deleteCheckIn(bookingId);
	}
	
	
}
