package com.auth.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.auth.model.Flight;

@FeignClient(name="flightservice", url="http://localhost:8082/")
public interface FlightClient {

	@PostMapping("/flight/addFlight")
	public Flight addFlight(@RequestBody Flight flight);
	
	
	@GetMapping("/flight/searchByCity/{departCity}/{arrivalCity}")
	public List<Flight> searchFlight(@PathVariable String departCity,@PathVariable String arrivalCity);
	
	@GetMapping("/flight/findByNumber/{flightNo}")
	public Flight getByFlightNo(@PathVariable long flightNo) ;
	
	@GetMapping("/flight/findAll")
	public List<Flight> findAll();
	
	@DeleteMapping("/flight/deleteById/{flightNo}")
	public boolean deleteById(@PathVariable long flightNo);
	
	@PutMapping("/flight/update")
	public Flight updateFlight(@RequestBody Flight flight) ;
}
