package com.auth.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.auth.client.BookingClient;
import com.auth.model.Booking;
import com.auth.model.Flight;
import com.auth.model.Passenger;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/auth/booking/")
public class BookingController {

	@Autowired
	private BookingClient bookingClient;
	

	@PostMapping("/addBooking/{username}")
	public String addBooking(@RequestBody Booking booking,@PathVariable String username) {
		return this.bookingClient.addBooking(booking,username);
	}
	

	@GetMapping("/findById/{flightNo}")
	public Flight getFlight(@PathVariable long flightNo) {
		return this.bookingClient.getFlight(flightNo);
	}
	

	@DeleteMapping("/deleteById/{bookingId}")
	public String deleteById(@PathVariable String bookingId) {
		return bookingClient.deleteById(bookingId);
	}
	

	@GetMapping("/findInfo/{bookingId}")
	public Booking getFlightInfo(@PathVariable String bookingId) {
		return bookingClient.getFlightInfo(bookingId);
	}
	
	@GetMapping("/findAllByUsername/{username}")
	public List<Booking> getAllBookingsByUsername(@PathVariable String username){
		return bookingClient.getAllBookingsByUsername(username);
	}
	
	@GetMapping("/findAllByFlightNo/{flightNo}")
	public List<Booking> getAllBookingsByFlightNo(@PathVariable long flightNo){
		return bookingClient.getAllBookingsByFlightNo(flightNo);
	}
	
	
	
	
}
