package com.auth.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.auth.client.FlightClient;
import com.auth.model.Flight;

@RestController
@RequestMapping("/auth/flight")
public class FlightController {

	
	@Autowired
	private FlightClient flightClient;
	

	@PostMapping("/admin/addFlight")
	public Flight addFlight(@RequestBody Flight flight) {
		return flightClient.addFlight(flight);
	}
	

	@GetMapping("/user/searchByCity/{departCity}/{arrivalCity}")
	public List<Flight> searchFlight(@PathVariable String departCity,@PathVariable String arrivalCity){

		return flightClient.searchFlight(departCity, arrivalCity);
	}
	

	@GetMapping("/user/findByNumber/{flightNo}")
	public Flight getByFlightNo(@PathVariable long flightNo) {
		return flightClient.getByFlightNo(flightNo);
	}
	

	@GetMapping("/user/findAll")
	public List<Flight> findAll(){
		return flightClient.findAll();
	}
	

	@DeleteMapping("/admin/deleteById/{flightNo}")
	public boolean deleteById(@PathVariable long flightNo) {
		return flightClient.deleteById(flightNo);
	}
	

	@PutMapping("/admin/update")
	public Flight updateFlight(@RequestBody Flight flight) {
		return flightClient.updateFlight(flight);
	}
	
}
