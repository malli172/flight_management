package com.auth.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.auth.model.Booking;
import com.auth.model.Flight;
import com.auth.model.Passenger;

import jakarta.validation.Valid;

@FeignClient(name="bookingService", url="http://localhost:8083/")
public interface BookingClient {

	@PostMapping("/booking/addBooking/{username}")
	public String addBooking(@RequestBody Booking booking,@PathVariable String username) ;
	

	
	@GetMapping("/booking/findById/{flightNo}")
	public Flight getFlight(@PathVariable long flightNo) ;
	
	@DeleteMapping("/booking/deleteById/{bookingId}")
	public String deleteById(@PathVariable String bookingId) ;
	
	
	
	@GetMapping("/booking/findInfo/{bookingId}")
	public Booking getFlightInfo(@PathVariable String bookingId) ;

	@GetMapping("/booking/findAllByUsername/{username}")
	public List<Booking> getAllBookingsByUsername(@PathVariable String username);
	
	@GetMapping("/booking/findAllByFlightNo/{flightNo}")
	public List<Booking> getAllBookingsByFlightNo(@PathVariable long flightNo);
	
	@GetMapping("/booking/checkIn/checkExists/{bookingId}")
	public Boolean checkExist(@PathVariable String bookingId);
	
}
