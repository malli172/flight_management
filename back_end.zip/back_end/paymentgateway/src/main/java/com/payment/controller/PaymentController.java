package com.payment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.payment.model.TransactionDetails;
import com.payment.service.PaymentService;

@RestController
@CrossOrigin("*")
public class PaymentController {

	@Autowired
	public PaymentService service;
	
	@GetMapping("/createTransaction/{amount}")
	public TransactionDetails createTransaction(@PathVariable double amount) {
		return service.createTransaction(amount);
	}
	
}
