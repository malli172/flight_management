package com.payment.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="transaction")
public class TransactionDetails {

	@Id
	private String order_id;
	private String currency;
	private double amount;
	private String key;
	public String getOrderId() {
		return order_id;
	}
	public void setOrderId(String orderId) {
		this.order_id = orderId;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public TransactionDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TransactionDetails(String orderId, String currency, double amount, String key) {
		super();
		this.order_id = orderId;
		this.currency = currency;
		this.amount = amount;
		this.key = key;
	}
	
	
}
