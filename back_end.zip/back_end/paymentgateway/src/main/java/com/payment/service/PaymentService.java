package com.payment.service;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 

import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.payment.model.TransactionDetails;
import com.payment.repo.PaymentRepo;
import com.razorpay.Order;
 
@Service
public class PaymentService {
 
	private static final String KEY = "rzp_test_ZZT2owDKbDuZE0";
	private static final String KEY_SECRET = "LkW31bPqnI64kymR1grv0l5s";
	private static final String CURRENCY = "INR";
 
	@Autowired
	private PaymentRepo repo;
	
	public TransactionDetails createTransaction(Double amount) {
 
		try {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("amount", (amount * 100));
			jsonObject.put("currency", CURRENCY);
 
			RazorpayClient razorpayClient = new RazorpayClient(KEY, KEY_SECRET);
 
			Order order = razorpayClient.orders.create(jsonObject);
			TransactionDetails transactionDetails = prepareTrasactionDetails(order);
			return repo.save(transactionDetails);
		} catch (RazorpayException e) {
			e.printStackTrace();
		}
		return null;
	}
 
	public TransactionDetails prepareTrasactionDetails(Order order) {
		String orderId = order.get("id");
		String currency = order.get("currency");
		int amount = order.get("amount");
		System.out.println(order);
		TransactionDetails transactionDetails = new TransactionDetails(orderId, currency, amount,KEY);
		return transactionDetails;
	}
 
}
 