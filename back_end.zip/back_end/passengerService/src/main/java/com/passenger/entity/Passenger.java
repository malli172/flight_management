package com.passenger.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.constraints.NotBlank;

@Document(collection="passenger")
public class Passenger {
	
	
	@Id
	private String passengerId;
	@NotBlank(message="FirstName is required")
	private String firstname;
	@NotBlank(message="LastName is required")
	private String lastname;
	@NotBlank(message="Gender is required")
	private String gender;
	@NotBlank(message="Age is required")
	private int age;
	private int seatno;
	
	
	private long flightNo;
	
	
	public Passenger() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

	
	public long getFlightNo() {
		return flightNo;
	}





	public void setFlightNo(long flightNo) {
		this.flightNo = flightNo;
	}





	public Passenger(String passengerId, String firstname, String lastname, String gender, int age, 
			int seatno, long flightNo) {
		super();
		this.passengerId = passengerId;
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		this.age = age;
		this.seatno = seatno;
		
	}





	public int getSeatno() {
		return seatno;
	}





	public void setSeatno(int seatno) {
		this.seatno = seatno;
	}






	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
	
	public String getPassengerId() {
		return passengerId;
	}


	public void setPassengerId(String passengerId) {
		this.passengerId = passengerId;
	}


	
	

}

