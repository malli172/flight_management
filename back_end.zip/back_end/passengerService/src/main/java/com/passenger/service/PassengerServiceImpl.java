package com.passenger.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.passenger.entity.Passenger;
import com.passenger.repo.PassengerRepo;

@Service
public class PassengerServiceImpl implements PassengerService{
	
	@Autowired
	private PassengerRepo repo;

	@Override
	public Passenger addPassenger(Passenger passenger) {
		return repo.save(passenger);
	}

	@Override
	public Passenger getPassenger(String passenger) {
		return repo.findByFirstname(passenger);
	}

	@Override
	public List<Passenger> getAllPassenger() {
		return repo.findAll();
	}

	@Override
	public String deletePassenger(String passengerId) {
		repo.deleteById(passengerId);
		return "Deleted successfully";
	}

	@Override
	public String delete(int seat,long flightNo) {
		Passenger p = repo.findBySeatnoAndFlightNo(seat,flightNo);
		if(p!=null) {
		repo.delete(p);
		return "deleted passengers";
		}
		return "not deleted"+p.getFirstname()+p.getFlightNo()+p.getSeatno();
	}

	
	
}
