package com.passenger.repo;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.passenger.entity.Passenger;

@Repository
public interface PassengerRepo extends MongoRepository<Passenger,String>{

	
	public Passenger findByFirstname(String name);
	
	public Passenger findBySeatnoAndFlightNo(int number,long flightNo);
}
