package com.booking.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.booking.model.Passenger;

@FeignClient(name="passengerService",url="http://localhost:8091/")
public interface PassengerProxy {

	@PostMapping("/addPassenger")
	public Passenger addPassenger(@RequestBody Passenger passenger);
	
	
	@DeleteMapping("/delete/{seat}/{flightNo}")
	public String delete(@PathVariable int seat,@PathVariable long flightNo);
	
	
}
