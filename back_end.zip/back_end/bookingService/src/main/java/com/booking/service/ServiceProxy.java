package com.booking.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.booking.model.Flight;

@FeignClient(name="flightservice",url="http://localhost:8082/")
public interface ServiceProxy {

	@GetMapping("/flight/findByNumber/{flightNo}")
	public Flight getFlight(@PathVariable long flightNo);
}
