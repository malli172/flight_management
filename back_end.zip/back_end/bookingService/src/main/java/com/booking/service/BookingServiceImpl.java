package com.booking.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.booking.exception.BookingNotFoundException;
import com.booking.exception.FlightNotFoundException;
import com.booking.model.Booking;
import com.booking.model.Flight;
import com.booking.model.Passenger;
import com.booking.repo.BookingRepo;

import lombok.extern.slf4j.Slf4j;

import com.booking.exception.*;

@Service
@Slf4j
public class BookingServiceImpl implements BookingService{
	
	

	@Autowired
	private BookingRepo repo;
	
	@Autowired
	EmailClient email;

	
	@Autowired
	private ServiceProxy proxy;
	
	@Autowired
	private CheckInProxy cproxy;
	
	@Autowired
	private PassengerProxy passengerProxy;
	
	
	

	
	@Override
	public String addBooking(Booking booking,String username) throws SeatsNotAvailableException {
		if(this.findFlightById(booking.getFlightNo())==null) {
			log.error("flight not found");
			throw new FlightNotFoundException("flight not found");
		}
		if(booking.getTransactionId()==null) {
			log.error("Payment failed");
			return "Payment failed";
		}
		
		List<Integer> list = new ArrayList<>();
		
		for(Passenger p: booking.getPassengers()) {
			int seat = this.alotSeat(booking.getFlightNo(),list);
			if(seat!=0) {
				p.setSeatno(seat);
				p.setFlightNo(booking.getFlightNo());
				list.add(seat);
				this.passengerProxy.addPassenger(p);
			}
			else {
				log.error("Seats are not available");
				throw new SeatsNotAvailableException("Seats are not available");
			}
		}
		booking.setSeats(list);
		booking.setFare(this.getFare(booking.getFlightNo(), booking.getPassengers()));
		this.repo.save(booking);
		String name= booking.getUsername();
		String msg = "Congratulation!!!!! "+name+" You have booked the ticket successfully";
		this.email.sendEmail(booking.getEmail(),"Flight Ticket Booking Confirmation ",msg+"");
		log.info("Your booking is confirmed and your reference number is "+booking.getBookingId()+" seats are "+booking.getSeats());
		return "Your booking is confirmed and your reference number is "+booking.getBookingId()+" seats are "+booking.getSeats();
	}
	
	
	@Override
	public Flight findFlightById(long id) throws FlightNotFoundException{
		if(proxy.getFlight(id)!=null) {
			log.info("flight fetched ");
			return proxy.getFlight(id);
		}
		else {
			log.error("flight is not present");
			throw new FlightNotFoundException("flight is not present");
		}
	}
	
	@Override
	public int alotSeat(long flightNo,List<Integer> list) {
		Flight obj = this.findFlightById(flightNo);
		for(int i=1;i<obj.getSeatCapacity();i++) {
			Optional<Booking> booking = repo.findByPassengersSeatnoAndFlightNo(i, flightNo);
			if(booking.isEmpty() && !list.contains(i)) {
				return i;
			}
		}
		return 0;
	}
	
	
	@Override
	public double getFare(long flightNo,List<Passenger> passenger) {
		Flight flight = this.findFlightById(flightNo);
		return flight.getFare()*passenger.size();
	}
	
	
	@Override
	public String deleteBooking(String bookingId) throws BookingNotFoundException {
	    Optional<Booking> booking = repo.findById(bookingId);
	    if (booking.isPresent()) {
	        System.out.println("Booking ID: " + bookingId);
	        
	        List<Integer> list = booking.get().getSeats();
	        for(int i : list) {
	        	this.passengerProxy.delete(i, booking.get().getFlightNo());
	        }

	       

	        repo.deleteById(bookingId);
	        if(cproxy.checkExist(bookingId)) {
	        	cproxy.deleteCheckIn(bookingId);
	        }
	        	String msg = "Hi  "+booking.get().getUsername()+" You have cancelled the flight ticket successfully";
	    		this.email.sendEmail(booking.get().getEmail(),"Flight ticket Cancellation Confirmation ",msg+"");
	    		log.info("Flight ticket deleted successfully");
	        return "Flight ticket deleted successfully";
	    } else {
	    	log.error("Booking id not available");
	        throw new BookingNotFoundException("Booking id not available");
	    }
	}

	
	@Override
	public Booking bookingInfo(String bookingId) throws BookingNotFoundException {
		Optional<Booking> booking = repo.findById(bookingId);
		if(booking.isPresent()) {
			log.info("found booking data");
			return booking.get();
		}
		else {
			log.error("Booking id not available");
			throw new BookingNotFoundException("Booking id not available");
		}
	}
	
	@Override
	public List<Booking> getAllBookingsByUsername(String username){
		return repo.findByUsername(username);
	}
	
	@Override
	public List<Booking> getAllBookingsByFlightNo(long flightNo){
		return repo.findByFlightNo(flightNo);
	}


	@Override
	public Boolean checkExists(String bookingId) {
		// TODO Auto-generated method stub
		return this.cproxy.checkExist(bookingId);
	}


	


}
