package com.booking.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="passenger")
public class Passenger {
	
	
	@Id
	private String passengerId;
	private String firstname;
	private String lastname;
	private String gender;
	private int age;
	private int seatno;
	private long flightNo;
	
	
	public long getFlightNo() {
		return flightNo;
	}





	public void setFlightNo(long flightNo) {
		this.flightNo = flightNo;
	}





	public Passenger() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

	
	public Passenger(String passengerId, String firstname, String lastname, String gender, int age, 
			int seatno, long flightNo) {
		super();
		this.passengerId = passengerId;
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		this.age = age;
		this.seatno = seatno;
		
	}





	public int getSeatno() {
		return seatno;
	}





	public void setSeatno(int seatno) {
		this.seatno = seatno;
	}






	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
	
	public String getPassengerId() {
		return passengerId;
	}


	public void setPassengerId(String passengerId) {
		this.passengerId = passengerId;
	}

	
	
	

}
