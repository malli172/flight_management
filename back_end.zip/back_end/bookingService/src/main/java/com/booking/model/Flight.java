package com.booking.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "flight")
public class Flight {

	@Id
	private long flightNo;
	private String departureCity;
	private String arrivalCity;
	private Date departureDate;
	private double fare;
	private int seatCapacity;
	public Flight() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Flight(long flightNo, String departureCity, String arrivalCity, Date departureDate, double fare,
			int seatCapacity) {
		super();
		this.flightNo = flightNo;
		this.departureCity = departureCity;
		this.arrivalCity = arrivalCity;
		this.departureDate = departureDate;
		this.fare = fare;
		this.seatCapacity = seatCapacity;
	}
	public long getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(long flightNo) {
		this.flightNo = flightNo;
	}
	public String getDepartureCity() {
		return departureCity;
	}
	public void setDepartureCity(String departureCity) {
		this.departureCity = departureCity;
	}
	public String getArrivalCity() {
		return arrivalCity;
	}
	public void setArrivalCity(String arrivalCity) {
		this.arrivalCity = arrivalCity;
	}
	public Date getDepartureDate() {
		return departureDate;
	}
	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}
	public double getFare() {
		return fare;
	}
	public void setFare(double fare) {
		this.fare = fare;
	}
	public int getSeatCapacity() {
		return seatCapacity;
	}
	public void setSeatCapacity(int seatCapacity) {
		this.seatCapacity = seatCapacity;
	}
	@Override
	public String toString() {
		return "Flight [flightNo=" + flightNo + ", departureCity=" + departureCity + ", arrivalCity=" + arrivalCity
				+ ", departureDate=" + departureDate + ", fare=" + fare + ", seatCapacity=" + seatCapacity + "]";
	}
	
}
