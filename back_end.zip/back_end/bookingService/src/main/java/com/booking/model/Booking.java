package com.booking.model;



import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

@Document(collection="booking")
public class Booking {

	@Id
	private String bookingId;
	private long flightNo;
	private double fare;
	private List<Passenger> passengers;
	private List<Integer> seats;
	private String transactionId;
	private String username;
	@NotBlank(message = "Email is required")
	@Email(message = "Invalid email format")
	private String email;
	
	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}
	


	
	



	public Booking(String bookingId, long flightNo, double fare, List<Passenger> passengers, List<Integer> seats,
			String transactionId, String username, String email) {
		super();
		this.bookingId = bookingId;
		this.flightNo = flightNo;
		this.fare = fare;
		this.passengers = passengers;
		this.seats = seats;
		this.transactionId = transactionId;
		this.username = username;
		this.email = email;
	}








	public String getEmail() {
		return email;
	}








	public void setEmail(String email) {
		this.email = email;
	}








	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	
	public String getBookingId() {
		return bookingId;
	}


	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}


	public long getFlightNo() {
		return flightNo;
	}


	public void setFlightNo(long flightNo) {
		this.flightNo = flightNo;
	}

	
	


	




	public List<Passenger> getPassengers() {
		return passengers;
	}








	public void setPassengers(List<Passenger> passengers) {
		this.passengers = passengers;
	}








	public List<Integer> getSeats() {
		return seats;
	}








	public void setSeats(List<Integer> seats) {
		this.seats = seats;
	}








	public Booking(String bookingId, long flightNo, double fare, List<Passenger> passengers, List<Integer> seats,
			String transactionId, String username) {
		super();
		this.bookingId = bookingId;
		this.flightNo = flightNo;
		this.fare = fare;
		this.passengers = passengers;
		this.seats = seats;
		this.transactionId = transactionId;
		this.username = username;
	}








	public double getFare() {
		return fare;
	}


	public void setFare(double fare) {
		this.fare = fare;
	}


	

	public String getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	
}
