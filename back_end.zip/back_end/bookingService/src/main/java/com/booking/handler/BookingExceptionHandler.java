package com.booking.handler;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import com.booking.exception.BookingNotFoundException;
import com.booking.exception.FlightNotFoundException;
import com.booking.exception.SeatsNotAvailableException;

 
@RestControllerAdvice
public class BookingExceptionHandler  {
 
 
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<?> handleAllExceptions(Exception ex) {
 
		
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.UNAUTHORIZED);
	}
 
 
	@ExceptionHandler(BookingNotFoundException.class)
	public final ResponseEntity<?> handleNotFoundException(BookingNotFoundException ex) {
	   
		return new ResponseEntity<>("Exception message--->  "+ex.getMessage(), HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(FlightNotFoundException.class)
	public final ResponseEntity<?> handleNotFoundException(FlightNotFoundException ex) {
 
		return new ResponseEntity<>("Exception message--->  "+ex.getMessage(), HttpStatus.NOT_FOUND);
		
	}

 
	@ExceptionHandler(SeatsNotAvailableException.class)
	public final ResponseEntity<?> handleNotFoundException(SeatsNotAvailableException ex) {
 
		return new ResponseEntity<>("Exception message--->  "+ex.getMessage(), HttpStatus.NOT_FOUND);
		
	}
 
}

