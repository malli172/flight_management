package com.booking.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="checkInService",url="http://localhost:8084/")
public interface CheckInProxy {

	@DeleteMapping("/checkIn/{bookingId}")
	public String deleteCheckIn(@PathVariable String bookingId);
	
	@GetMapping("/checkIn/checkExists/{bookingId}")
	public Boolean checkExist(@PathVariable String bookingId);
	

}
