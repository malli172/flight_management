package com.booking.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


@FeignClient(name="emailService", url="http://localhost:9093/")
public interface EmailClient {

	@GetMapping("mail/{toMail}/{subject}/{body}")
	public void sendEmail(@PathVariable String toMail,@PathVariable String subject,@PathVariable String body);
}
