package com.booking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.booking.exception.BookingNotFoundException;
import com.booking.exception.FlightNotFoundException;
import com.booking.exception.SeatsNotAvailableException;
import com.booking.model.Booking;
import com.booking.model.Flight;
import com.booking.service.BookingService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/booking")
public class BookingController {
	
	@Autowired
	private BookingService service;

	@PostMapping("/addBooking/{username}")
	public String addBooking(@Valid @RequestBody Booking booking,@PathVariable String username) throws SeatsNotAvailableException {
		return service.addBooking(booking, username);
	}
	

	
	@GetMapping("/findById/{flightNo}")
	public Flight getFlight(@PathVariable long flightNo) throws FlightNotFoundException {
		return service.findFlightById(flightNo);
	}
	
	
	@DeleteMapping("/deleteById/{bookingId}")
	public String deleteById(@PathVariable String bookingId) throws BookingNotFoundException{
		return service.deleteBooking(bookingId);
	}
	
	
	
	@GetMapping("/findInfo/{bookingId}")
	public Booking getFlightInfo(@PathVariable String bookingId)  throws BookingNotFoundException {
		return service.bookingInfo(bookingId);
	}

	@GetMapping("/findAllByUsername/{username}")
	public List<Booking> getAllBookingsByUsername(@PathVariable String username){
		return service.getAllBookingsByUsername(username);
	}
	
	@GetMapping("/findAllByFlightNo/{flightNo}")
	public List<Booking> getAllBookingsByFlightNo(@PathVariable long flightNo){
		return service.getAllBookingsByFlightNo(flightNo);
	}
	
	@GetMapping("/checkIn/checkExists/{bookingId}")
	public Boolean checkExist(@PathVariable String bookingId) {
		return service.checkExists(bookingId);
	}
	
}
