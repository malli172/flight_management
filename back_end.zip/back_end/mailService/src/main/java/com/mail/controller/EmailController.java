package com.mail.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.mail.service.EmailService;

@RestController
public class EmailController {

	
	@Autowired
	private EmailService service;
	
	@GetMapping("mail/{toMail}/{subject}/{body}")
	public void sendEmail(@PathVariable String toMail,@PathVariable String subject,@PathVariable String body) {
		this.service.sendEmail(toMail, subject, body);
	}
}
