package com.checkin.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;


@RestControllerAdvice
public class CheckInExceptionHandler {

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<?> handleAllExceptions(Exception ex) {
 
		
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.UNAUTHORIZED);
	}
 
 
	@ExceptionHandler(BookingNotFoundException.class)
	public final ResponseEntity<?> handleNotFoundException(BookingNotFoundException ex) {
	   
		return new ResponseEntity<>("Exception message--->  "+ex.getMessage(), HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(CheckInAlreadyExistException.class)
	public final ResponseEntity<?> handleNotFoundException(CheckInAlreadyExistException ex) {
 
		return new ResponseEntity<>("Exception message--->  "+ex.getMessage(), HttpStatus.NOT_FOUND);
		
	}
	
	
	
	

}
