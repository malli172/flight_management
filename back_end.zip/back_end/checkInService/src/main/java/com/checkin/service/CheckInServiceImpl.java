package com.checkin.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.checkin.exception.BookingNotFoundException;
import com.checkin.exception.CheckInAlreadyExistException;
import com.checkin.model.*;
import com.checkin.model.CheckIn;
import com.checkin.repo.CheckInRepo;

import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class CheckInServiceImpl implements CheckInService{

	@Autowired
	private CheckInRepo repo;
	
	@Autowired
	private BookingProxy bookingService;
	
	@Autowired
	private EmailClient email;
	
	@Override
	public String performCheckIn(String bookingReference)throws CheckInAlreadyExistException,BookingNotFoundException{
		
		Booking booking = bookingService.getBookingInfo(bookingReference);
		if(booking==null) {
			log.error("Booking is not available");
			throw new BookingNotFoundException("Booking is not available");
		}
		if(repo.existsByBookingId(bookingReference)) {
			log.error("You have already checked in and your seat number "+booking.getSeats());
			throw new CheckInAlreadyExistException("You have already checked in and your seat number "+booking.getSeats());
		}
		else {
			
			CheckIn checkin = new CheckIn();
			checkin.setBookingId(bookingReference);
			checkin.setCheckedIn(true);
			checkin.setSeats(booking.getSeats());
			repo.save(checkin);
			String name= booking.getUsername();
			String msg = "Hiii!!!! "+name+" You have checked In successfully. Seats ---> "+booking.getSeats();
			this.email.sendEmail(booking.getEmail(),"CheckIn Confirmation ",msg+"");
			log.info("You have checked In And Your seat number is ->"+checkin.getSeats());
			return "You have checked In And Your seat number is ->"+checkin.getSeats();
		}
	}
	
	@Override
	public String deleteCheckIn(String bookingId) {
		CheckIn checkin = repo.findByBookingId(bookingId);
		if(checkin != null) {
			repo.delete(checkin);
			log.info("Deleted checkin");
			return "Deleted checkin";
		}
		log.error("Not Checked In");
		return "Not Checked In";
	}

	@Override
	public boolean checkExists(String bookingId) {
		
		return this.repo.existsByBookingId(bookingId);
	}
	
	
}
