package com.checkin.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.checkin.model.Booking;

@FeignClient(name="bookingService",url="http://localhost:8083/")
public interface BookingProxy {

	
	@GetMapping("/booking/findInfo/{bookingId}")
	public Booking getBookingInfo(@PathVariable String bookingId);

}
