package com.checkin.service;

import com.checkin.exception.BookingNotFoundException;
import com.checkin.exception.CheckInAlreadyExistException;

public interface CheckInService {

	public String performCheckIn(String bookingReference) throws CheckInAlreadyExistException,BookingNotFoundException;
	
	public String deleteCheckIn(String bookingId);
	
	public boolean checkExists(String bookingId);
}
