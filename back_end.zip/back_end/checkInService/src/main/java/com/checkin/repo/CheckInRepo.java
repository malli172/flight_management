package com.checkin.repo;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import com.checkin.model.CheckIn;
import com.checkin.model.Flight;

@Repository
public interface CheckInRepo extends MongoRepository<CheckIn,String>{
	
	public Boolean existsByBookingId(String bookingId);
	
//	public CheckIn findByPassengerSeatno(long flightNo);
	
	public CheckIn findByBookingId(String bookingId);
	


}
