package com.checkin.exception;

public class CheckInAlreadyExistException extends RuntimeException{

	
	public CheckInAlreadyExistException(String msg) {
		super(msg);
	}
}
