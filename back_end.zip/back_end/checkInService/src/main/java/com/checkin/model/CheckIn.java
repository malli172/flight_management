package com.checkin.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="checkIn")
public class CheckIn {
	
	@Id
	private String id;
	private boolean checkedIn;
	private List<Integer> seats;
	private String bookingId;
	public CheckIn() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public CheckIn(String id, boolean checkedIn, List<Integer> seats, String bookingId) {
		super();
		this.id = id;
		this.checkedIn = checkedIn;
		this.seats = seats;
		this.bookingId = bookingId;
	}

	public List<Integer> getSeats() {
		return seats;
	}

	public void setSeats(List<Integer> seats) {
		this.seats = seats;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public boolean isCheckedIn() {
		return checkedIn;
	}
	public void setCheckedIn(boolean checkedIn) {
		this.checkedIn = checkedIn;
	}
	
	public String getBookingId() {
		return bookingId;
	}
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	
	
	
}
