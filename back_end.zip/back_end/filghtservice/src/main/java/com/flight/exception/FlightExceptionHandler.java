package com.flight.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.flight.exception.FlightNotFoundException;

@RestControllerAdvice
public class FlightExceptionHandler  {
 
 
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<?> handleAllExceptions(Exception ex) {
 
		
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.UNAUTHORIZED);
	}
 
 
	
	
	@ExceptionHandler(FlightNotFoundException.class)
	public final ResponseEntity<?> handleNotFoundException(FlightNotFoundException ex) {
 
		return new ResponseEntity<>("Exception message--->  "+ex.getMessage(), HttpStatus.NOT_FOUND);
		
	}
	
	@ExceptionHandler(FlightAlreadyExistException.class)
	public final ResponseEntity<?> handleNotFoundException(FlightAlreadyExistException ex) {
 
		return new ResponseEntity<>("Exception message--->  "+ex.getMessage(), HttpStatus.NOT_FOUND);
		
	}
}