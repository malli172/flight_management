package com.flight.repo;


import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import com.flight.model.Flight;

@Repository
public interface FlightRepo extends MongoRepository<Flight, Long>{

	public Boolean existsByFlightNo(long flightNo);
	public List<Flight> findByDepartureCityAndArrivalCity(String departCity, String arrivalCity);
}
