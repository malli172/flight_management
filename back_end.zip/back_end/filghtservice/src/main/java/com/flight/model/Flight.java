package com.flight.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Document(collection = "flight")
public class Flight {
	@Id
	private long flightNo;
	
	@NotBlank(message = "Departure city cannot be empty")
    @Size(min = 3, max = 20, message = "departure city should be between 3 and 20 characters")
	private String departureCity;
	
	@NotBlank(message = "Arrival City cannot be empty")
    @Size(min = 3, max = 20, message = "Arrrival city should be between 3 and 20 characters")
	private String arrivalCity;
	private Date departureDate;
	@Min(value = 0, message = "fare should be a positive number")
	private double fare;
	
	@Min(value = 0, message = "seat capacity should be a positive number")
	private int seatCapacity;
	public Flight() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Flight(long flightNo, String departureCity, String arrivalCity, Date departureDate, double fare,
			int seatCapacity) {
		super();
		this.flightNo = flightNo;
		this.departureCity = departureCity;
		this.arrivalCity = arrivalCity;
		this.departureDate = departureDate;
		this.fare = fare;
		this.seatCapacity = seatCapacity;
	}
	public long getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(long flightNo) {
		this.flightNo = flightNo;
	}
	public String getDepartureCity() {
		return departureCity;
	}
	public void setDepartureCity(String departureCity) {
		this.departureCity = departureCity;
	}
	public String getArrivalCity() {
		return arrivalCity;
	}
	public void setArrivalCity(String arrivalCity) {
		this.arrivalCity = arrivalCity;
	}
	public Date getDepartureDate() {
		return departureDate;
	}
	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}
	public double getFare() {
		return fare;
	}
	public void setFare(double fare) {
		this.fare = fare;
	}
	public int getSeatCapacity() {
		return seatCapacity;
	}
	public void setSeatCapacity(int seatCapacity) {
		this.seatCapacity = seatCapacity;
	}
	@Override
	public String toString() {
		return "Flight [flightNo=" + flightNo + ", departureCity=" + departureCity + ", arrivalCity=" + arrivalCity
				+ ", departureDate=" + departureDate + ", fare=" + fare + ", seatCapacity=" + seatCapacity + "]";
	}
	

}
