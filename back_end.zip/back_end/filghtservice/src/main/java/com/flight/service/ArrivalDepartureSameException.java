package com.flight.service;

public class ArrivalDepartureSameException extends RuntimeException{

	public ArrivalDepartureSameException(String msg) {
		super(msg);
	}
}
