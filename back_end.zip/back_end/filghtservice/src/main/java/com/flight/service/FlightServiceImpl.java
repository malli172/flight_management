package com.flight.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flight.exception.FlightAlreadyExistException;
import com.flight.exception.FlightNotFoundException;
import com.flight.model.Flight;
import com.flight.repo.FlightRepo;
import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class FlightServiceImpl implements FlightService{

	@Autowired
	FlightRepo flightRepo;
	
	@Override
	public Flight addFlight(Flight flight)throws ArrivalDepartureSameException, FlightAlreadyExistException {
		if(flightRepo.existsById(flight.getFlightNo())) {
			throw new FlightAlreadyExistException("Flight Number already exists");
		}
		if(flight.getDepartureCity().equalsIgnoreCase(flight.getArrivalCity())) {
			log.error("Arrival and Departure city should not be same");
			throw new ArrivalDepartureSameException("Arrival and Departure city should not be same");
		}
		log.info("flight information saved successfully");
		return flightRepo.save(flight);
	}
	
	@Override
	public List<Flight> searchFlight(String departCity, String arrivalCity) throws FlightNotFoundException{
		List<Flight> flights = flightRepo.findByDepartureCityAndArrivalCity(departCity, arrivalCity);
		if(flights.size()==0) {
			log.error("flights not found");
			throw new FlightNotFoundException("flights not found");
		}
		else {
			log.info("flights fetched successfully");
		return flights;
		}
	}
	
	@Override
	public Flight findByNumber(long flightNo) throws FlightNotFoundException {
		Optional<Flight> flight = flightRepo.findById(flightNo);
		if(flight.isPresent()) {
			log.info("flight information "+flight);
			return flight.get();
		}
		else {
			log.error("flight not exist");
			throw new FlightNotFoundException("flight not exist");
		}
	}
	
	@Override
	public List<Flight> getAll(){
		log.info("flights fetched");
		return flightRepo.findAll();
	}
	
	
	@Override
	public boolean deleteById(long flightNo)throws FlightNotFoundException {
		Optional<Flight> flight = flightRepo.findById(flightNo);
		if(flight.isEmpty()) {
			log.error("flight not exist");
			return false;
		}
		flightRepo.deleteById(flightNo);
		return true;
	}
	
	
	@Override
	public Flight updateFlight(Flight flight) throws FlightNotFoundException{
		Optional<Flight> obj = flightRepo.findById(flight.getFlightNo());
		if(obj.isPresent()) {
			Flight old = obj.get();
			flightRepo.delete(old);
			log.info("flight updated successfully");
			return flightRepo.save(flight);
		}
		log.error("flight not exist");
		throw new FlightNotFoundException("flight not exist");
	}
}
