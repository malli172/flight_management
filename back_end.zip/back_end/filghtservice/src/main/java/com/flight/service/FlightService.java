package com.flight.service;

import java.util.List;

import com.flight.exception.FlightAlreadyExistException;
import com.flight.exception.FlightNotFoundException;
import com.flight.model.Flight;

public interface FlightService {

	public Flight addFlight(Flight flight)throws ArrivalDepartureSameException, FlightAlreadyExistException;
	
	public List<Flight> searchFlight(String departCity, String arrivalCity) throws FlightNotFoundException;
	
	public Flight findByNumber(long flightNo) throws FlightNotFoundException;
	
	public List<Flight> getAll();
	
	public boolean deleteById(long flightNo)throws FlightNotFoundException;
	
	public Flight updateFlight(Flight flight)throws FlightNotFoundException;
}
