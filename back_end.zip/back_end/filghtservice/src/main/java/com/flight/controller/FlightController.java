package com.flight.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flight.exception.FlightAlreadyExistException;
import com.flight.exception.FlightNotFoundException;
import com.flight.model.Flight;
import com.flight.service.ArrivalDepartureSameException;
import com.flight.service.FlightService;
import com.flight.service.FlightServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/flight")
public class FlightController {

	@Autowired
	FlightService flightService;
	
	@PostMapping("/addFlight")
	public Flight addFlight(@Valid @RequestBody Flight flight) throws ArrivalDepartureSameException, FlightAlreadyExistException {
		return flightService.addFlight(flight);
	}
	
	@GetMapping("/searchByCity/{departCity}/{arrivalCity}")
	public List<Flight> searchFlight(@PathVariable String departCity,@PathVariable String arrivalCity)throws FlightNotFoundException{
		return flightService.searchFlight(departCity, arrivalCity);
	}
	
	@GetMapping("/findByNumber/{flightNo}")
	public Flight getByFlightNo(@PathVariable long flightNo) throws FlightNotFoundException{
		return flightService.findByNumber(flightNo);
	}
	
	@GetMapping("/findAll")
	public List<Flight> findAll(){
		return flightService.getAll();
	}
	
	@DeleteMapping("/deleteById/{flightNo}")
	public boolean deleteById(@PathVariable long flightNo) throws FlightNotFoundException{
		return flightService.deleteById(flightNo);
	}
	
	@PutMapping("/update")
	public Flight updateFlight(@RequestBody Flight flight) throws FlightNotFoundException{
		return flightService.updateFlight(flight);
	}
	
}
