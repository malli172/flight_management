package com.flight.exception;

public class FlightAlreadyExistException extends RuntimeException{

	public FlightAlreadyExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
