import { CanActivateFn } from '@angular/router';

export const authGuard: CanActivateFn = (route, state) => {
  let token= localStorage.getItem("token");
    if(token==undefined && token=='' && token==null ){
      return false;
    }
    else{
      return true;
    }
  
};

