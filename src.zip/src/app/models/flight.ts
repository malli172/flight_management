export class Flight {
    flightNo:number=0;
    departureCity:string="";
    arrivalCity:string="";
    fare:number=0;
    departureDate:string="";
    seatCapacity:number=0;

}
