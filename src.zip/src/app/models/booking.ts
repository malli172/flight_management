export class Booking {
    flightNo:number=0;
    fare:number=0;
    passengers:string[]=[];
    seats:number[]=[];
    transactionId:string="";
    username:string="";
    email:string="";
}
