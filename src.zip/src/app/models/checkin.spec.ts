import { Checkin } from './checkin';

describe('Checkin', () => {
  it('should create an instance', () => {
    expect(new Checkin()).toBeTruthy();
  });
});
