export class Checkin {
    checkedIn:boolean=false;
    seats:number[]=[];
    bookingId:string="";
}
