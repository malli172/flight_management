import { Component } from '@angular/core';
import { FlightService } from '../../services/flight.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'app-flight',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './flight.component.html',
  styleUrl: './flight.component.css'
})
export class FlightComponent {

  flight:any=[];
   constructor(private service: FlightService){}

   ngOnInit(){
    this.getAllFlights();
   }

   getAllFlights(){
    this.service.getFlightList().subscribe(
      (response)=>{
        this.flight=response;
      }
    )
   }

}
