import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UserService } from '../../services/user.service';
import { response } from 'express';
import { error } from 'console';
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

data={
  username:'',
  password:''
}

  constructor(private service: UserService){}

  login(){
    if((this.data.username!='' && this.data.password!='') && (this.data.username!=null && this.data.password!=null) ){
        this.service.doLogin(this.data).subscribe(
          (response)=>{
              console.log(response);
              
          },
          (error)=>{
              console.log(error);
          }
        )
    }
    else{
      console.log("Fields are empty !!");
    }
  }
}
