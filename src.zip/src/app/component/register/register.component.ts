import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {

  status:string="";
  constructor(private userService: UserService){}

    register(registerForm: any){
      this.userService.register(registerForm.value).subscribe(
        (response)=>{
              console.log(response);
              this.status="Registered Successfully";
        },
        (error) => {
          if (error.status === 400) {
            console.log("Username or emailId already exists. Please give correct data.");
            this.status="Username or emailId already exists. Please give correct data.";
          } else {
            console.log("An error occurred:", error);
          }
        }
      );

    }
}

