import { Routes } from '@angular/router';
import { RegisterComponent } from './component/register/register.component';
import { LoginComponent } from './component/login/login.component';
import { FlightComponent } from './component/flight/flight.component';
import { BookingComponent } from './component/booking/booking.component';

export const routes: Routes = [
    {path:'register',component:RegisterComponent},
    {path:'login',component:LoginComponent},
    {path:'flight', component:FlightComponent},
    {path:'booking', component:BookingComponent}
];
