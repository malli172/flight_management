import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { response } from 'express';
import { text } from 'stream/consumers';
@Injectable({
  providedIn: 'root'
})
export class UserService {

  url: string = "http://localhost:8909/auth/api";
  constructor(private http: HttpClient) { }


  doLogin(data:any){
    return this.http.post(this.url+"/signin",data);
  }


  register(registerData:any){
    return this.http.post(this.url+"/signup",registerData);
  }

  isLoggedIn(){
    let token= localStorage.getItem("token");
    if(token==undefined && token=='' && token==null ){
      return false;
    }
    else{
      return true;
    }
  }

  loginUser(res:any){
    localStorage.setItem("token",res.token);
    return true;
  }
  
  logout(){
    localStorage.removeItem('token');
    return true;
  }

  getToken(){
    return localStorage.getItem("token");
  }



}
