import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Booking } from '../models/booking';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  url: string = "http://localhost:8083/booking";

  constructor(private http: HttpClient) { }

  addBooking(booking: Booking,username: string){
    return this.http.post(this.url+"/addBooking/"+username,booking);
  }



  cancelBooking(bookingId: string){
    return this.http.delete(this.url+"/deleteById/"+bookingId);
  }

  findAllBooking(username: string){
    return this.http.get(this.url+"/findAllByUsername/"+username);
  }

  findAllByFlightNo(flightNo: string){
    return this.http.get(this.url+"/findAllByFlightNo/"+flightNo);
  }

  getBookingInfo(bookingId: string){
    return this.http.get(this.url+"/findInfo/"+bookingId);
  }


}
