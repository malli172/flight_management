import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Flight } from '../models/flight';
@Injectable({
  providedIn: 'root'
})
export class FlightService {

  url: string = "http://localhost:8082/flight";
  constructor(private http: HttpClient) { }

  addFlight(flight: Flight){
    return this.http.post<Flight>(this.url+"/addFlight",flight);
  }

  getFlightList(){
    return this.http.get(this.url+"/findAll");
  }

  updateFlight(flight:Flight){
    return this.http.put(this.url+"/update/",flight);
  }

  getFlightById(flightNo:string){
    return this.http.get(this.url+"/findByNumber/"+flightNo);
  }

  deleteFlight(flightNo:string){
    return this.http.delete(this.url+"/deleteById/"+flightNo);
  }

  searchFlight(departureCity:string, arrivalCity:string){
    return this.http.get(this.url+"/"+departureCity+"/"+arrivalCity);
  }


}
