import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CheckInService {

  url: string = "http://localhost:8084/checkIn";

  constructor(private http: HttpClient) { }

  
  performCheckIn(bookingId: string){
    return this.http.get(this.url+"/"+bookingId);
  }


}
